package regex;

public class Regex1 {

   
    public static void main(String[] args) {
        String udaj = "301 00";
        String regex = "[1-7]\\d{2} \\d{2}";
        if (udaj.matches(regex)) {
            System.out.println("ok");
        } else {
            System.out.println("ko");
        }
        
    }
    
}
