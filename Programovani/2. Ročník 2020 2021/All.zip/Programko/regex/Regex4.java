package regex;

public class Regex4 {

    public static void main(String[] args) {
        String udaj = "Joe";
        String regex = "[A-Z][a-z]{2,}";
        if (udaj.matches(regex)) {
            System.out.println("ok");
        } else {
            System.out.println("ko");
        }
        
    }
    
}

