package regex;

public class Regex5 {

    public static void main(String[] args) {
        String udaj = "pan Joe Novák";
        String regex = "(pan|paní|slečna)[A-Z][a-z]+ [A-Z][a-z]+";
        if (udaj.matches(regex)) {
            System.out.println("ok");
        } else {
            System.out.println("ko");
        }
        
    }
    
}
