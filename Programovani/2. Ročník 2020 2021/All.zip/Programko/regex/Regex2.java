package regex;

public class Regex2 {


    public static void main(String[] args) {
        String udaj = "050209/1234";
        String regex = "\\d{2} [0156]\\d[0-3]\\d/\\d{3,4}";
        if (udaj.matches(regex)) {
            System.out.println("ok");
        } else {
            System.out.println("ko");
        }
        
    }
    
}