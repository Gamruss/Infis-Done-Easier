package regex;

public class Regex3 {

    public static void main(String[] args) {
        String udaj = "1A2 1234";
        String regex = "\\d[ABCEHJKLMPSTUZ]\\d \\d{4}";
        if (udaj.matches(regex)) {
            System.out.println("ok");
        } else {
            System.out.println("ko");
        }
        
    }
    
}
