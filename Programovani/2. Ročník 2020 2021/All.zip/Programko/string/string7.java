/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package string;

/**
 *
 * @author Acry
 */
public class string7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String  jmeno = "jan noVÁk";
        // Jan NOVÁK
        // muž bez přičítání
        String rc = "000125/1234";
        // žena + 5 na 3. pozici rodného čísla
        String bruh = "005125/1234";        
    }
    
}
