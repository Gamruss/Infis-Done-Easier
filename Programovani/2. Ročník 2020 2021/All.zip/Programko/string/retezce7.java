/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package string;
/**
 *
 * @author Acry
 */
public class retezce7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String jmeno = "VácLAv PRoKop";
        int mezera = 0;
        for(int i=0;i<jmeno.length();i++){
             if(Character.isWhitespace(jmeno.charAt(i))){
                 mezera = i;
             }
        
       }
        String prvnipismeno = jmeno.substring(0,1);
        prvnipismeno = prvnipismeno.toUpperCase();
        String krestniJmeno = jmeno.substring(1, mezera);
        krestniJmeno = krestniJmeno.toLowerCase();
        krestniJmeno = prvnipismeno.concat(krestniJmeno);
        System.out.print(krestniJmeno);
        String prijmeni = jmeno.substring(mezera+1, jmeno.length());
        prijmeni = prijmeni.toUpperCase();
        System.out.println(" "+prijmeni);
    }
    
}
