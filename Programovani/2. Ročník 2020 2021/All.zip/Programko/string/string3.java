
package string;


public class string3 {

    public static void main(String[] args) {
        String text = "něco";
        
        if (text.equals(text.toLowerCase())) {
         String[] jmena = {"Karel", "Marie", "Anna", "Franta", "Václav"}; 
         
         for (int i = 0; i < jmena.length; i++) {
             if (i == 0 || i == jmena.length - 1) {
                 System.out.println(jmena[i].toUpperCase());
             } else {
                 System.out.println(jmena[i]);
             }
         }
        }
    }
    
}
