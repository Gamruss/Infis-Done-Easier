/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package string;

/**
 *
 * @author Acry
 */
public class retezce1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String[] jmena = {"petr","pavel","jan","evzen"};
       String uzivJmeno = "evzen";
       for (int i = 0;i<4;i++){
         if(jmena[i]==uzivJmeno){
             System.out.println("Jméno "+jmena[i]+" se shoduje");
         }
         
         
       }
    }
    
}
