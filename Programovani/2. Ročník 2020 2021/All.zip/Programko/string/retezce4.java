/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package string;

/**
 *
 * @author Acry
 */
public class retezce4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     String text = "Ranní rosa existuje.";
     char ch;
     char ch1;

     for(int i=0;i<text.length()-1;i++){
         ch = text.charAt(i);
         
         
         for (int j = i+1;j<i+2;j++){
             ch1 = text.charAt(j);
             
            
             
           if(ch == ch1){
                 System.out.println("Nalezl jsem dvě stejná písmena na pozici "+i+" a "+j);    
               
             }
           
         }
         
    }
        
    }
    }   
