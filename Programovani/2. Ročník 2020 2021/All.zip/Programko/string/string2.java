/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package string;

/**
 *
 * @author Acry
 */
public class string2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String[] jmena = {"Karel", "Marie", "Anna", "Franta"};
        String uzivJmeno = "Anna";
        
        boolean nalezeno = false;
        
        for (String jmeno : jmena) {
            if (uzivJmeno.equalsIgnoreCase(jmeno))
                nalezeno = true;
        }
        if (nalezeno) {
            System.out.println("uživatel " + uzivJmeno + "nalezen");
        } else {
            System.out.println("uživatel " + uzivJmeno + "nenalezen");
        }
    }
    
}
