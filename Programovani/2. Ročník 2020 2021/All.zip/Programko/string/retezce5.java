/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package string;

/**
 *
 * @author Acry
 */
public class retezce5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String rodnecislo = "990301/4578";
        char pismeno;
        for(int i=0;i<rodnecislo.length();i++){
             pismeno = rodnecislo.charAt(i);
                 if(pismeno == '/') {
                     if(i==6){
                         System.out.println("Lomítko je na 7. pozici");
                     }
                     else{
                         System.out.println("Lomítko jsem nalezl, ale nachází se na pozici: "+(i+1));
                     }
                 
             }
             
        }
    }
    
}
