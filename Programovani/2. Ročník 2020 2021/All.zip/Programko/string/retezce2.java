/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package string;

/**
 *
 * @author Acry
 */
public class retezce2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     String text = "zde je text pro tento ukol";
     char ch;
     int pocitadlo = 0;
     for(int i=0;i<text.length();i++){
         ch = text.charAt(i);
         if(Character.isUpperCase(ch)){
             pocitadlo ++;
         }
         
     }
        System.out.println("Systém zaznamenal "+pocitadlo+" velkých písmen");
        if(pocitadlo == 0){
            System.out.println("Text bude překonvertován na velká písmena");
        System.out.println(text.toUpperCase());
        }
    }
    
}
