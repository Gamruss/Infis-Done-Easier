/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package string;

/**
 *
 * @author Acry
 */
public class retezce6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String retezec = "Jedna veta pro tento ukol";
       char ch;
       char ch1;
       String vysledek = "";
       for (int i =0;i<retezec.length();i++){
           if(i % 2 ==0){
                 ch = retezec.charAt(i);
                ch1=Character.toUpperCase(ch);
                vysledek = vysledek + ch1;
           }
           else{
               ch = retezec.charAt(i);
               ch1=Character.toLowerCase(ch);
               vysledek = vysledek + ch1;
           }
       }
        System.out.println(vysledek);
       
    }
    
}
