/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package string;

/**
 *
 * @author Acry
 */
public class string4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String text = "Apple";
        boolean zdvojena = false;
        
        for (int i = 0; i < text.length()-1; i++) {
            if (text.charAt(i) == text.charAt(i+1)) {
                zdvojena = true;
            }
        }
        
        if (zdvojena) {
            System.out.println("jsou tam");
        } else {
            System.out.println("nejsou tam");
        }
    }
    
}
