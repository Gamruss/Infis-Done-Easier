/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package string;

/**
 *
 * @author Acry
 */
public class retezce8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           String rodnecislo = "996301/4578";
        char pismeno;
        for(int i=0;i<rodnecislo.length();i++){
             pismeno = rodnecislo.charAt(i);
                
                 if(i == 2) {
                     int l = Character.getNumericValue(pismeno);
                    
                     if(l >= 5 ){
                         System.out.println("Jsi žena");
                     }
                     else{
                         System.out.println("Jsi muž");
                     }
                 
             }
             
        }
    }
    
}


