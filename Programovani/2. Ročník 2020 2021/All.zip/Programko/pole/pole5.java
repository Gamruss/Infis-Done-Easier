/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pole;
import java.util.Scanner;
import java.util.Arrays;



/**
 *
 * @author Acry
 */
public class pole5 {
    public static int[] pridani_prvku(int n, int cisla[], int cislo) {
       int pole[] = new int [n+1];
        for (int i = 0; i<n; i++){ 
              pole[i] = cisla[i];
              pole[n] = cislo;
              
        }
        return pole;
    }
   public static void main(String[] args) {
       System.out.println("Zadej číslo:");
        Scanner sc = new Scanner(System.in);
        
        int cislo = sc.nextInt();
        int[] cisla = {cislo};
        int n=1;
       
       while(cislo!=-1){
       System.out.println("Zadej číslo:");
        Scanner pocet = new Scanner(System.in);
        cislo = pocet.nextInt();
        cisla = pridani_prvku(n,cisla,cislo);
        
        
        n= n+1;
        
           
       }
       System.out.println(Arrays.toString(cisla));
       

       
   }
}
