/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pole;
import java.util.Scanner;
import java.util.Random;
/**
 *
 * @author Acry
 */
public class pole4 {
  public static void main(String[] args) {
       System.out.println("Zadej počet čísel:");
        Scanner pocet = new Scanner(System.in);
        int n = pocet.nextInt();
        int[] cisla = new int[n];
        for(int i = 0; i<n;i++){
            Random rd = new Random();
            int cislo = rd.nextInt();
            cisla[i] = cislo;
            System.out.println("cislo("+i+") = "+cisla[i]);
        }
  }  
}
