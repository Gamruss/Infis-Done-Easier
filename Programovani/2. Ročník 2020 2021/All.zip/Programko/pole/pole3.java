/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pole;
import java.util.Scanner;
import java.util.Arrays;
/**
 *
 * @author Acry
 */
public class pole3 {
    public static void main(String[] args) {
        String[][] barvy= { {"cervena","anglicky","red"},{"cervena","nemecky","das Rot"},{"cervena","rusky","кра́сный цвет"},{"cervena","italsky","rosso"},{"cervena","slovinsky","rdeča barva"},
        {"zluta","anglicky","yellow"},{"zluta","nemecky","das Gelb"},{"zluta","rusky","жёлтая"},{"zluta","italsky","giallo"},{"zlutá","slovinsky","rumen"},
        {"oranzova","anglicky","orange"},{"oranzova","nemecky","das Orange"},{"oranzova","rusky","ора́нжевый цвет"},{"oranzova","italsky","arancione"},{"oranzova","slovinsky","rumena"},
        {"fialova","anglicky","purple"},{"fialova","nemecky","das Violett"},{"fialova","rusky","фиоле́товый"},{"fialova","italsky","viola"},{"fialova","slovinsky","vijoličast"},
        {"modra","anglicky","blue"},{"modra","nemecky","das Blau"},{"modra","rusky","си́ний цвет"},{"modra","italsky","celeste"},{"modra","slovinsky","modra barva"},
        {"zelena","anglicky","green"},{"zelena","nemecky","das Grün"},{"zelena","rusky","зелёный цвет"},{"zelena","italsky","verde"},{"zelena","slovinsky","zelena barva"},
        {"cerna","anglicky","black"},{"cerna","nemecky","das Schwarz"},{"cerna","rusky","чёрный цвет"},{"cerna","italsky","nero"},{"cerna","slovinsky","črna"}};
        
 
        Scanner sc = new Scanner(System.in);
        System.out.println("Zadej jazyk: (anglicky, nemecky, rusky, italsky, slovinsky)");
      String jazyk = sc.nextLine();
        System.out.println("Zadej barvu: (cervená, zluta, oranzova, fialova, modra, zelena, cerna)");
      String barva = sc.nextLine();
        
        int indexim= 0;
        int indexjm= 0;
       for (int i = 0 ; i < barvy.length; i++)
     for(int j = 0 ; j < barvy[i].length ; j++)
        {
           
         if ( barvy[i][j].equals(barva) )
                
         {
              indexim = i;
              indexjm = j;
              break;
         }
            
    }
       System.out.println("indexy barev");
       System.out.println(indexim);
       System.out.println(indexjm);
       
        
       
        int indexid= 0;
        int indexjd= 0;
       for (int i = 0 ; i < barvy.length; i++)
     for(int j = 1 ; j < barvy[i].length ; j++)
        {
          
         if ( barvy[i][j].equals(jazyk) ){
                
         if(i<= indexim){
            
         
              indexid = i;
              indexjd = j;
              break;
         }
         }
         
            
    }
        System.out.println("indexy jazyku");
       System.out.println(indexid);
       System.out.println(indexjd);
       
        System.out.println(barvy[indexid][indexjm+2]);
    }
}
