
package pole;

import java.util.Scanner;


public class pole1 {

     public static String zjisteniKraje(String spz){
        
      
        String udaje[][] = {{"A", "Praha"}, {"B", "Jihomoravský kraj"},{"C", "Jihočeský kraj"},{"E","Pardubický kraj"},{"H","Královéhradecký kraj"},{"J","Kraj Vysočina"}
                           ,{"K","Karlovarský kraj"},{"L", "Liberecký kraj"},{"M", "Olomoucký kraj"},{"P","Plzeňský kraj"},{"S","Středočeský kraj"},{"T","Moravskoslezský kraj"}
                           ,{"U","Ústecký kraj"},{"Z","Zlínský kraj"} };
        
        String kraj = "";
        String kraj1 = "";
        char ch=spz.charAt(1);
        kraj = Character.toString(ch);
        if(kraj.equals(udaje[0][0])){
          kraj1 = udaje[0][1];
            System.out.println(kraj1);
        }
        if(kraj.equals(udaje[1][0])){
            kraj1 = udaje[1][1];
            System.out.println(kraj1);
        }
        if(kraj.equals(udaje[2][0])){
            kraj1 = udaje[2][1];
            System.out.println(kraj1);
        }
        if(kraj.equals(udaje[3][0])){
            kraj1 = udaje[3][1];
            System.out.println(kraj1);
        }
        if(kraj.equals(udaje[4][0])){
            kraj1 = udaje[4][1];
            System.out.println(kraj1);
        }
        if(kraj.equals(udaje[5][0])){
            kraj1 = udaje[5][1];
            System.out.println(kraj1);
        }
        if(kraj.equals(udaje[6][0])){
            kraj1 = udaje[6][1];
            System.out.println(kraj1);
        }
        if(kraj.equals(udaje[7][0])){
            kraj1 = udaje[7][1];
            System.out.println(kraj1);
        }
        if(kraj.equals(udaje[8][0])){
            kraj1 = udaje[8][1];
            System.out.println(kraj1);
        }
        if(kraj.equals(udaje[9][0])){
            kraj1 = udaje[9][1];
            System.out.println(kraj1);
        }
        if(kraj.equals(udaje[10][0])){
            kraj1 = udaje[10][1];
            System.out.println(kraj1);
        }
        if(kraj.equals(udaje[11][0])){
            kraj1 = udaje[11][1];
            System.out.println(kraj1);
        }
        if(kraj.equals(udaje[12][0])){
            kraj1 = udaje[12][1];
            System.out.println(kraj1);
        }
        if(kraj.equals(udaje[13][0])){
            kraj1 = udaje[13][1];
            System.out.println(kraj1);
        }
        
        return kraj1;
       
    }

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
         System.out.println("Zadej Registrační značku (vzor: 1P83475)");
         String spz = sc.nextLine();
        zjisteniKraje(spz);
    }
    
}