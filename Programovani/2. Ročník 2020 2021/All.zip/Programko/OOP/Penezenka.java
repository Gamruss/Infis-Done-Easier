/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOP;

/**
 *
 * @author Acry
 */
public class Penezenka {
    public int zustatek;
    public int hodnota;
    
    public void zjistiZustatek(){
        System.out.println("V peněžence je: "+zustatek);
    }
    
    public int vlozCastku(int hodnota){
        zustatek = zustatek+hodnota;
      return zustatek;  
    }
    
    public int vyberCastku(int hodnota){
        zustatek = zustatek-hodnota;
       return zustatek; 
    }
}
