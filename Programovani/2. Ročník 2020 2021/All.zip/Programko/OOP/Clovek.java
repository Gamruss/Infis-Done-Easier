/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOP;

/**
 *
 * @author Acry
 */
public class Clovek {
    public String jmeno;
     public String prijmeni;
    
    
    public String vratCeleJmeno(){
        return String.format("%s %s", jmeno, prijmeni);
    }
}

