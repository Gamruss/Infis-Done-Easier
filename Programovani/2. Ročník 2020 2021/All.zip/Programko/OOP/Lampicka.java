/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOP;

/**
 *
 * @author Acry
 */
public class Lampicka {
    public String svetlo = "Lampička je zhasnutá";
    
    public void zjistiStav(){
        System.out.println(svetlo);
    }
    
    public String zhasni(){
        svetlo = "Lampička je zhasnutá";
        return svetlo;
        
    }
    
    public String rozsvit(){
        svetlo = "Lampička svítí";
        return svetlo;
    }
}
