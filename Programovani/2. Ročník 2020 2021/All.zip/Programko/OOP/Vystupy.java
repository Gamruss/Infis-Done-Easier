/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOP;

/**
 *
 * @author Acry
 */
public class Vystupy {
    public static void main(String[] args){
        Clovek pepa = new Clovek();
        pepa.jmeno = "Pepa";
        pepa.prijmeni = "Kropáček";
        System.out.println(pepa.vratCeleJmeno());
        System.out.println("\n");
        
        Obdelnik ob1 = new Obdelnik();
        ob1.strA = 4;
        ob1.strB = 5;
        System.out.println("Obvod obdelníka je: "+ob1.obvod());
        System.out.println("Obsah obdelníka je: "+ob1.obsah());
        System.out.println("\n");
         
        Lampicka lam = new Lampicka();
        lam.rozsvit();
        lam.zjistiStav();
        lam.zhasni();
        lam.zjistiStav();
        System.out.println("\n");
        
        Penezenka penPepa = new Penezenka();
        penPepa.vlozCastku(200);
        penPepa.zjistiZustatek();
        penPepa.vyberCastku(100);
        penPepa.zjistiZustatek();
        
        
    }
}
