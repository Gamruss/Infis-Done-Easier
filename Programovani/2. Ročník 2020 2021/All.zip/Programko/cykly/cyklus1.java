/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cykly;
import java.util.Scanner;
/**
 *
 * @author Acry
 */
public class cyklus1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
       System.out.println("Zadejte číslo n:");
       Scanner sc = new Scanner(System.in);
       int n2 = sc.nextInt();
       System.out.println("Zadal jsi "+n2);
       System.out.println("Matice "+n2+"x"+n2);
       n2=n2*n2;
     
       for(int i = 1;i<=n2;i++){
           System.out.println(i);
    }
    }
    
}
