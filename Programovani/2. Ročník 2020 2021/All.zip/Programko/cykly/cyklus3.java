/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cykly;
import java.util.Random;

/**
 *
 * @author Acry
 */
public class cyklus3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Random rd = new Random();
        int c = rd.nextInt(6)+1;
        System.out.println(c);
        while (c != 6) {
         c = rd.nextInt(6)+1;
         System.out.println(c);
        }
        
        System.out.println("Našlo se číslo 6");
                
    }
    
}
