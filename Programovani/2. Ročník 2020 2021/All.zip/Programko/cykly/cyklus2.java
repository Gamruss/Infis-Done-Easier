/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cykly;
import java.util.Scanner;
import java.util.Random;
/**
 *
 * @author Acry
 */
public class cyklus2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Zadej počet čísel:");
        Scanner pocet = new Scanner(System.in);
        int n = pocet.nextInt();
       int pocitadlo = 0;
        int[] cisla = new int[n];   
        for(int i = 0; i<n;i++){
            Random rd = new Random();
            int cislo = rd.nextInt(5); 
            if(cislo == 0){
                pocitadlo++;
            }
            cisla[i] = cislo;
            
            System.out.println("Vygenerovalo se číslo: "+cisla[i]);
    }
        System.out.println("Hodnota 0 se v poli objevila: "+pocitadlo+" krát");
    }
    
}
