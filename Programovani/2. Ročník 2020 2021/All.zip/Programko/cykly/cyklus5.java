/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cykly;
import java.util.Scanner;
 
/**
 *
 * @author Acry
 */
public class cyklus5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Zadej počet mocnin");
       Scanner sc = new Scanner(System.in);
       int pocet = sc.nextInt();
        double exponent = 2;
       while(pocet<=0){
           System.out.println("Zadal jsi záporné číslo nebo 0, zadej počet znovu:");
            pocet = sc.nextInt();
           
       }
       double mocnina=0;
       for(int i = 1;i<=pocet;i++){
           mocnina=Math.pow(i, exponent);
           System.out.println(i+"^2= "+mocnina);
           
       }
    }
    
}
