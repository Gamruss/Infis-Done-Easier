/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cykly;
import java.util.Scanner;
/**
 *
 * @author Acry
 */
public class cyklus4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Zadej hodnotu n faktoriálu:");
       Scanner sc = new Scanner(System.in);
       double cislo = sc.nextDouble();
       if(cislo>50){
           System.out.println("Zadal jsi větší číslo než 50");
          System.exit(0);
       }
       double pom=1;
       if(cislo<0){
               System.out.println("Faktoriál neexistuje");
              
           }
           else if(cislo==0){
               System.out.println(cislo+"!= "+pom);
               
           }
           else{
       for(int i=1;i<=cislo;i++){
           
           
        pom=pom*i;
           }
       System.out.println(cislo+"!= "+pom);
       }
        
    }
    
}
