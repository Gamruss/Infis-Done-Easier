
package metody;
import java.util.Scanner;
/**
 *
 * @author Acry
 */
public class metody3 {

    public static void zjisteniKraje(){
         Scanner sc=new Scanner(System.in);
         System.out.println("Zadej Registrační značku (vzor: 1P83475");
        String spz = sc.nextLine();
        String kraj = "";
        String kraj1 = "";
        char ch=spz.charAt(1);
        kraj = Character.toString(ch);
        if(kraj.equals("A")){
            kraj1 = "Praha";
            System.out.println(kraj1);
        }
        if(kraj.equals("B")){
            kraj1 = "Jihomoravský kraj";
            System.out.println(kraj1);
        }
        if(kraj.equals("C")){
            kraj1 = "Jihočeský kraj";
            System.out.println(kraj1);
        }
        if(kraj.equals("E")){
            kraj1 = "Pardubický kraj";
            System.out.println(kraj1);
        }
        if(kraj.equals("H")){
            kraj1 = "Královéhradecký kraj";
            System.out.println(kraj1);
        }
        if(kraj.equals("J")){
            kraj1 = "Kraj Vysočina";
            System.out.println(kraj1);
        }
        if(kraj.equals("K")){
            kraj1 = "Karlovarský kraj";
            System.out.println(kraj1);
        }
        if(kraj.equals("L")){
            kraj1 = "Liberecký kraj";
            System.out.println(kraj1);
        }
        if(kraj.equals("M")){
            kraj1 = "Olomoucký kraj";
            System.out.println(kraj1);
        }
        if(kraj.equals("P")){
            kraj1 = "Plzeňský kraj";
            System.out.println(kraj1);
        }
        if(kraj.equals("S")){
            kraj1 = "Středočeský kraj";
            System.out.println(kraj1);
        }
        if(kraj.equals("T")){
            kraj1 = "Moravskoslezský kraj";
            System.out.println(kraj1);
        }
        if(kraj.equals("U")){
            kraj1 = "Ústecký kraj";
            System.out.println(kraj1);
        }
        if(kraj.equals("Z")){
            kraj1 = "Zlínský kraj";
            System.out.println(kraj1);
        }
        
        
       
    }

    public static void main(String[] args) {
        zjisteniKraje();
    }
    
}
