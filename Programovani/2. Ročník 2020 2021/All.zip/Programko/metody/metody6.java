
package metody;
import java.util.Scanner;
import java.util.Random;
import java.util.Arrays;
/**
 *
 * @author Acry
 */
public class metody6 {


    public static int vypisMin(int[] pole){
        int minimum1 = pole[1];
        for (int i =0;i<pole.length;i++){
            if(minimum1>pole[i]){
             minimum1 = pole[i];   
            }
        }
        return minimum1;
    }
    
      public static int vypisMax(int[] pole){
           int maximum1 = pole[1];
        for (int i =0;i<pole.length;i++){
            if(maximum1<pole[i]){
             maximum1 = pole[i];   
            }
        }
        return maximum1;
    }
    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Zadejte délku pole:");
        int delka = sc.nextInt();
        int[] pole = new int[delka];
        for (int i = 0;i<delka;i++){
            System.out.println("Zadej "+(i+1)+". číslo v poli:");
           pole[i] = sc.nextInt();
           
        }
        int minimum = vypisMin(pole);
        System.out.println("Minimum je: "+minimum);
        int maximum = vypisMax(pole);
        System.out.println("Maximum je: "+maximum);
    }
    
}
