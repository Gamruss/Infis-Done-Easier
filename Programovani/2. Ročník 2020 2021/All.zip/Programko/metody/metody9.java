/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metody;
import java.util.Scanner;
import java.util.Arrays;
/**
 *
 * @author Acry
 */
public class metody9 {

    /**
     * @param args the command line arguments
     */
    public static String pozpatku(String slovo){
        String pozpatku = "";
        for(int i = slovo.length()-1;i>=0;i--){
            pozpatku = pozpatku+slovo.charAt(i);
        }
        System.out.println(pozpatku);
        return pozpatku;
    }
    
    public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
        System.out.println("Zadej slovo: ");
        String slovo = sc.nextLine();
        System.out.println("Slovo pozpátku: "+pozpatku(slovo));
    }
    
}
