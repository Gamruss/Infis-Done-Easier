/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metody;

/**
 *
 * @author Acry
 */
public class metody10 {

    /**
     * @param args the command line arguments
     */
    
    public static String zjisteniPohlavi(String rodnecislo){
        String pohlavi = "";
        
        char pismeno;
        for(int i=0;i<rodnecislo.length();i++){
             pismeno = rodnecislo.charAt(i);
                
                 if(i == 2) {
                     int l = Character.getNumericValue(pismeno);
                    
                     if(l >= 5 ){
                         pohlavi = "Jsi žena";
                     }
                     else{
                         pohlavi = "Jsi muž";
                     }
                 }
        }
    
        return pohlavi;
    }
    
    public static void main(String[] args) {
         String rodnecislo = "990301/4578";
         System.out.println(zjisteniPohlavi(rodnecislo));
    }

    
}
