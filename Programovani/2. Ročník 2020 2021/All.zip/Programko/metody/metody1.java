
package metody;
import java.util.Scanner;
import java.util.Random;
import java.util.Arrays;

public class metody1 {

   public static int[] vypocet(int n, int min, int max){
       int[] pole = new int[n];
       Random rd1=new Random();
       for(int i=0;i<n;i++){
           pole[i] = rd1.nextInt(max-min)+min;
           
       }
        return pole;
    }
    public static void main(String[] args) {
       System.out.println("Zadej minimální hodnotu:");
       Scanner sc = new Scanner(System.in);
       Random rd = new Random();
       int min = sc.nextInt();
       System.out.println("Zadej maximalní hodnotu:");
       int max = sc.nextInt();
       int n = rd.nextInt(20-1)+1;
        System.out.println("Počet čísel je:" +n);
        System.out.println(n);
        int vysledek[] = vypocet(n,min,max);
        System.out.println(Arrays.toString(vysledek));
       
       
    }
    
}
