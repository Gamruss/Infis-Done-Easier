
package metody;
import java.util.Scanner;
/**
 *
 * @author Acry
 */
public class metody7 {

    public static String zjisteniKraje(String spz){
        String kraj = "";
        String kraj1 = "";
        char ch=spz.charAt(1);
        kraj = Character.toString(ch);
        if(kraj.equals("A")){
            kraj1 = "Praha";
        }
        if(kraj.equals("B")){
            kraj1 = "Jihomoravský kraj";
        }
        if(kraj.equals("C")){
            kraj1 = "Jihočeský kraj";
        }
        if(kraj.equals("E")){
            kraj1 = "Pardubický kraj";
        }
        if(kraj.equals("H")){
            kraj1 = "Královéhradecký kraj";
        }
        if(kraj.equals("J")){
            kraj1 = "Kraj Vysočina";
        }
        if(kraj.equals("K")){
            kraj1 = "Karlovarský kraj";
        }
        if(kraj.equals("L")){
            kraj1 = "Liberecký kraj";
        }
        if(kraj.equals("M")){
            kraj1 = "Olomoucký kraj";
        }
        if(kraj.equals("P")){
            kraj1 = "Plzeňský kraj";
        }
        if(kraj.equals("S")){
            kraj1 = "Středočeský kraj";
        }
        if(kraj.equals("T")){
            kraj1 = "Moravskoslezský kraj";
        }
        if(kraj.equals("U")){
            kraj1 = "Ústecký kraj";
        }
        if(kraj.equals("Z")){
            kraj1 = "Zlínský kraj";
        }
        
        
        return kraj1;
    }

    public static void main(String[] args) {
         Scanner sc=new Scanner(System.in);
         System.out.println("Zadej Registrační značku (vzor: 1P83475");
         String spz = sc.nextLine();
        System.out.println(zjisteniKraje(spz));
    }
    
}
