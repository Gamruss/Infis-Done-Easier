/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metody;
import java.util.Scanner;
import java.util.Arrays;
/**
 *
 * @author Acry
 */
public class metody4 {

    /**
     * @param args the command line arguments
     */
    public static int vypocetDni(int den, int mesic){
        int pocet = 0;
        int[] poleMesicu = {31,28,31,30,31,30,31,31,30,31,30};
        if(mesic == 1){
            pocet = den;
        }
        if(mesic == 2){
            pocet = poleMesicu[1]+den;
        }
        if(mesic == 3){
            pocet = poleMesicu[1]+poleMesicu[2]+den;
        }
        if(mesic == 4){
            pocet = poleMesicu[1]+poleMesicu[2]+poleMesicu[3]+den;
        }
        if(mesic == 5){
            pocet = poleMesicu[1]+poleMesicu[2]+poleMesicu[3]+poleMesicu[4]+den;
        }
        if(mesic == 6){
            pocet = poleMesicu[1]+poleMesicu[2]+poleMesicu[3]+poleMesicu[4]+poleMesicu[5]+den;
        }
        if(mesic == 7){
            pocet = poleMesicu[1]+poleMesicu[2]+poleMesicu[3]+poleMesicu[4]+poleMesicu[5]+poleMesicu[6]+den;
        }
        if(mesic == 8){
            pocet = poleMesicu[1]+poleMesicu[2]+poleMesicu[3]+poleMesicu[4]+poleMesicu[5]+poleMesicu[6]+poleMesicu[7]+den;
        }
        if(mesic == 9){
            pocet = poleMesicu[1]+poleMesicu[2]+poleMesicu[3]+poleMesicu[4]+poleMesicu[5]+poleMesicu[6]+poleMesicu[7]+poleMesicu[8]+den;
        }
        if(mesic == 10){
            pocet = poleMesicu[1]+poleMesicu[2]+poleMesicu[3]+poleMesicu[4]+poleMesicu[5]+poleMesicu[6]+poleMesicu[7]+poleMesicu[8]+poleMesicu[9]+den;
        }
        if(mesic == 11){
            pocet = poleMesicu[1]+poleMesicu[2]+poleMesicu[3]+poleMesicu[4]+poleMesicu[5]+poleMesicu[6]+poleMesicu[7]+poleMesicu[8]+poleMesicu[9]+poleMesicu[10]+den;
        }
        if(mesic == 12){
            pocet = poleMesicu[1]+poleMesicu[2]+poleMesicu[3]+poleMesicu[4]+poleMesicu[5]+poleMesicu[6]+poleMesicu[7]+poleMesicu[8]+poleMesicu[9]+poleMesicu[10]+poleMesicu[11]+den;
        }
        return pocet;
    }
   
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Zadej den v měsíci: ");
        int den = sc.nextInt();
        System.out.println("Zadej měsíc v číselné podobě: ");
        int mesic = sc.nextInt();
        System.out.println("Počet dní od začátku roku je: "+ vypocetDni(den,mesic));

    }
    
}
