
package metody;
import java.util.Scanner;
import java.util.Random;
import java.util.Arrays;
/**
 *
 * @author Acry
 */
public class metody2 {


   public static void vypisMin(){        
        int[] pole = {8,15,3,8,9,25,108,47,6,3};
        int minimum1 = pole[1];
        for (int j =0;j<pole.length;j++){
            if(minimum1>pole[j]){
             minimum1 = pole[j];   
            }
        }
        System.out.println("Minimum je: "+minimum1);
        
    }
    
      public static void vypisMax(){
          int[] pole = {8,15,3,8,9,25,108,47,6,3};
           int maximum1 = pole[1];
        for (int i =0;i<pole.length;i++){
            if(maximum1<pole[i]){
             maximum1 = pole[i];   
            }
        }
          System.out.println("Maximum je: "+maximum1);

    }
    
    public static void main(String[] args) {
        vypisMin();
        vypisMax();
        
       
    
    }
    
}
