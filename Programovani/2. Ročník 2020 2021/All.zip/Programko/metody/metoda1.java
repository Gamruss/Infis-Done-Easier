package metody;

public class metoda1 {
    public static void pozdrav() {
        System.out.println("Ahoj");
        
    }
    
    public static void main(String[] args) {
      pozdrav();
      System.out.println("------");
      pozdrav();
    }
    
}
