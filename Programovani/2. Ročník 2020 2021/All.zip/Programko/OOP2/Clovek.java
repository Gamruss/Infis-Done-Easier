/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOP2;

/**
 *
 * @author Acry
 */
public class Clovek {
    private String jmeno, prijmeni;
    private int vek;
    
    public Clovek(){
        jmeno = "Alfons";
        prijmeni = "Mucha";
        vek = 54;
    }
    
    public Clovek(String n){
       jmeno =n;
       prijmeni = "Novy";
       vek = 5;       
    }
    
    public Clovek(String n, String s){
        jmeno = n;
        prijmeni = s;
        vek = 30;
    }
    
    public Clovek(String n, String s, int a){
        jmeno = n;
        prijmeni = s;
        vek = a;
        
    }
    public void info(){
        System.out.println(jmeno+" "+prijmeni+" "+vek);
       
    }
    
}
