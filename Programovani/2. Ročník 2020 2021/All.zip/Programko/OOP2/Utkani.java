/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOP2;

/**
 *
 * @author Acry
 */
public class Utkani{
    public String mistoKonani;
    public int skoreDomaci, skoreHoste;
    String pom;
    
    public int getskoreDomaci(){
        return skoreDomaci;
    }
    
    public int getskoreHoste(){
        return skoreHoste;
    }
    
    public String getmistoKonani(){
        return mistoKonani;
    }
    
    public void setskoreDomaci(int skoreDomaci){
        this.skoreDomaci=skoreDomaci;
    }
    
    public void setskoreHoste(int skoreHoste){
        this.skoreHoste=skoreHoste;
    }
    
    public void setmistoKonani(String mistoKonani){
        this.mistoKonani=mistoKonani;
    }
    
    public String vysledek(){
        if(skoreDomaci<skoreHoste){
            pom = "Výhra hostí";
            return pom;
        }else if(skoreDomaci>skoreHoste){
            pom = "Výhra domácí";
            return pom;
        }
            else{
                    pom = "Remíza";
                    return pom;
            }
            
        }
        
        
    }
    
    
    
    
    
    

