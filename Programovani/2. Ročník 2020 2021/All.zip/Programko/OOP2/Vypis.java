/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOP2;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Acry
 */
public class Vypis {
    
    
    public static void main(String[] args){
        Utkani ut = new Utkani();
        String mistoKonani = "Plzen";
        int skoreDomaci = 2;
        int skoreHoste = 3;
        
        ut.setmistoKonani(mistoKonani);
        ut.setskoreDomaci(skoreDomaci);
        ut.setskoreHoste(skoreHoste);
        System.out.println(ut.getmistoKonani());
        System.out.println(ut.getskoreDomaci());
        System.out.println(ut.getskoreHoste());
        
        System.out.println(ut.vysledek());
        System.out.println("\n");
        
        Ucet uc = new Ucet();
        int zustatek = 500;
        uc.pridaniPenez(zustatek);
        zustatek = 200;
        uc.pridaniPenez(zustatek);
        System.out.println(uc.vraceniZustatku());
        System.out.println("\n");
        
        Trojuhelnik tr = new Trojuhelnik();
        int stranaA = 5 ;
        int stranaB = 4;
        int stranaC = 4;
        
        tr.setstranaA(stranaA);
        tr.setstranaB(stranaB);
        tr.setstranaC(stranaC);
        
        System.out.println("a= "+tr.getstranaA());
        System.out.println("b= "+tr.getstranaB());
        System.out.println("c= "+tr.getstranaC());
        
        System.out.println("obvod = "+tr.obvod());
        System.out.println("obsah = "+tr.obsah());
        System.out.println("Trojúhelník je pravoúhlý: "+tr.jePravouhly(stranaA, stranaB, stranaC));
        System.out.println("\n");
    
    
        Clovek c1=new Clovek();
        c1.info();
        Clovek c2=new Clovek("Karel");
        c2.info();
        Clovek c3=new Clovek("Vaclav","Hruby");
        c3.info();
        Clovek c4=new Clovek("Petr","Rosomak",68);
        c4.info();
        
    }
    
}
