/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOP2;

/**
 *
 * @author Acry
 */
public class Ucet {
    public int zustatek;
    
     
    public void pridaniPenez(int zustatek){
   
      int pom = this.zustatek+zustatek;
      this.zustatek = pom;
    }
    
    public int vraceniZustatku(){
        return zustatek;
    }
    
}
