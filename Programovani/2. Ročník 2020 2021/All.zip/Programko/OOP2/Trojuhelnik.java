/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOP2;
import java.lang.Math;
/**
 *
 * @author Acry
 */
public class Trojuhelnik {
    public int stranaA, stranaB, stranaC;

    public int getstranaA() {
        return stranaA;
    }

    public int getstranaB() {
        return stranaB;
    }

    public int getstranaC() {
        return stranaC;
    }

    public void setstranaA(int stranaA) {
        this.stranaA = stranaA;
    }

    public void setstranaB(int stranaB) {
        this.stranaB = stranaB;
    }

    public void setstranaC(int stranaC) {
        this.stranaC = stranaC;
    }
    
    
    
    
public int obvod() { 
    return stranaA + stranaB + stranaC;
        }
public double obsah() { 
   double maleS=(stranaA+stranaB+stranaC);
   maleS = maleS/2;
   double pom = (maleS)*(maleS-stranaA)*(maleS-stranaB)*(maleS-stranaC);
   double s = Math.sqrt(pom);
   
   return s;
        }
public boolean jePravouhly(int stranaA,int stranaB,int stranaC) {
    boolean prav=false;
        
         if(stranaC*stranaC==stranaA*stranaA+stranaB*stranaB || stranaA*stranaA==stranaB*stranaB+stranaC*stranaC || stranaB*stranaB==stranaA*stranaA+stranaC*stranaC){
            prav=true;
            }
        
        
        else{
         prav=false;
         
        }
        return prav;
}

}
