/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package úkoly;
import java.util.Scanner;
/**
 *
 * @author Antonín Panc
 */
public class podminky3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Zadej Body u zkoušky AJ:");
        Scanner body = new Scanner(System.in);
        int pocetBoduAJ = body.nextInt();
        System.out.println("Počet bodů z AJ= "+pocetBoduAJ);
        
        System.out.println("Zadej Body u zkoušky M:");
        int pocetBoduM = body.nextInt();
        System.out.println("Počet bodů z M= "+pocetBoduM);
        
        int soucetBodu = pocetBoduAJ + pocetBoduM;
        System.out.println("Celkový počet bodů= "+soucetBodu);
        if(pocetBoduAJ <30){
            System.out.println("Neprošel jsi zkouškou z AJ, máš méně než 30 bodů");
        }else if(pocetBoduM <30){
            System.out.println("Neprošel jsi zkouškou z M, máš méně než 30 bodů");
        }else if(soucetBodu < 70){
            System.out.println("Neprošel jsi PZ, máš dohromady méně bodů než 70");
        }
        else{
            System.out.println("Prošel jsi ze všech zkoušek, Gratulují!");
        }
    }
    
}
