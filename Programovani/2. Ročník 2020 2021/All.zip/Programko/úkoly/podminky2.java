/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package úkoly;
import java.util.Scanner;
import java.util.Random;
/**
 *
 * @author Antonín Panc
 */
public class podminky2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Zadej počet všech známek");
        Scanner pocet = new Scanner(System.in);
        int pocetZnamek = pocet.nextInt();
        float prumer;
        float soucetZnamek = 0;
        int spatnaZnamka = 0;
        int[] znamky = new int[pocetZnamek];   
        for(int i = 0; i<pocetZnamek;i++){
            Random znam = new Random();
            int znamka = znam.nextInt(5);
            while(znamka == 0){
               znamka = znam.nextInt(5); 
            }
            znamky[i] = znamka;
           System.out.println("Vygenerovala se "+(i+1)+". známka = "+znamky[i]);
           soucetZnamek = soucetZnamek + znamky[i];
           if(znamky[i]>2){
              spatnaZnamka ++; 
           }
        }
       prumer = soucetZnamek / pocetZnamek;
        System.out.println("průměr je: "+prumer);
        System.out.println("Dostal jsi "+spatnaZnamka+" horších známek než 2");
        if(prumer <=1.5 && spatnaZnamka == 0){
            System.out.println("Prospěl jsi s vyznamenáním");
        }
        else{
            System.out.println("Prospěl jsi bez vyznamenání");
        }
       
        
       
    }
    
}
