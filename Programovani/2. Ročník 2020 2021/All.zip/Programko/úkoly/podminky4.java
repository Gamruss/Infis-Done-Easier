/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package úkoly;

import java.util.Scanner;

/**
 *
 * @author Antonín Panc
 */
public class podminky4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Umístění:");
        Scanner body = new Scanner(System.in);
        int kvalifikace = body.nextInt();
        System.out.println("Umístění= "+kvalifikace);
        
        System.out.println("Zadej Body:");
        int pocetBodu = body.nextInt();
        System.out.println("Počet bodů= "+pocetBodu);
        
        if(kvalifikace <4 || pocetBodu >180){
             System.out.println("Úspěšně jsi se kvalifikoval");
           
        }
        else{
            System.out.println("Neprošel jsi kvalifikací, jsi na horším než 4. místě a máš méně než 180 bodů");
        }
    }
    
}
