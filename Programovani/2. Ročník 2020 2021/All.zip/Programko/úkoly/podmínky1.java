/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package úkoly;

/**
 *
 * @author Antonín Panc
 */
public class podmínky1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int cislo = 0;
        if(cislo % 2 == 0){
        System.out.println("Číslo, které jsi zadal ("+cislo+") je sudé");
        }
        else{
            System.out.println("Číslo, které jsi zadal ("+cislo+") je liché");
        }
    }
    
}
