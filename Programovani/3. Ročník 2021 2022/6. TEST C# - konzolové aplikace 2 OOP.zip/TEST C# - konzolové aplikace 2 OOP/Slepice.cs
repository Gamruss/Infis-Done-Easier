﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Slepice
    {
        private string jmeno;
        private int zasobaEnergie;


        public string getJmeno()
        {
            return jmeno;
        }
        public int getZasobaEnergie()
        {
            return zasobaEnergie;
        }

        public void setJmeno(string Jmeno)
        {
            Jmeno = jmeno;
        }

        public void setZasobaEnergie(int ZasobaEnergie)
        {
            ZasobaEnergie = zasobaEnergie;
        }

        public void doplnEnergii(int energie)
        {
            zasobaEnergie = zasobaEnergie + energie;
        }

        public void nakrmKure(int Energie ,Kure kure)
        {
            if(zasobaEnergie < Energie)
            {
                
                kure.najezSe(Energie);
            }    
            else
            {
                Console.WriteLine("Neni dostatek energie"); 
            }
            
        }

        public Slepice()
        {

        }
        public Slepice(string jmeno)
        {
            this.jmeno = jmeno;
        }
    }
}
