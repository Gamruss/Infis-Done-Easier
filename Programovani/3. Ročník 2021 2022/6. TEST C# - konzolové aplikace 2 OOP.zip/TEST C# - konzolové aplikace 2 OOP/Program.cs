﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Kure Kure1 = new Kure("Kure1");
            Slepice Slepice1 = new Slepice("Slepice1");
            Slepice1.setZasobaEnergie(200);
            Slepice1.nakrmKure(500, Kure1);
            Console.WriteLine("Jmeno kuřete : "+Kure1.getJmeno());
            Console.WriteLine("Energie Kuřete : "+ Kure1.getEnergie());

        }
    }
}
