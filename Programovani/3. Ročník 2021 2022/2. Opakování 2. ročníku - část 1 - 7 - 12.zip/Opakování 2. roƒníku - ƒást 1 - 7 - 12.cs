﻿using System;
using System.Linq;
using System.Globalization;
using static System.Math;

namespace Opakovani
{
    class Program
    {
        public static void Ukol1_2()
        {
            Console.WriteLine("Úkol 1, 2");
            Console.WriteLine("Zadejte číslo od 1 až do 9");
            string input = Console.ReadLine();
            Console.WriteLine();

            if (int.TryParse(input, out int cislo) && cislo >= 0 && cislo <= 9)
            {
                for (int i = 0; i < cislo; i++)
                {
                    int kolik = i;
                    kolik++;
                    for (int p = 0; p < kolik; p++)
                    {
                        Console.Write(kolik);
                    }
                    Console.WriteLine("");
                }
            }
            else
            {
                Console.WriteLine("Error");
            }
            Console.WriteLine();
            moznost();
        }

        public static void Ukol3()
        {
            Console.WriteLine("Úkol 3");
            Console.WriteLine("Zadejte číslo");
            string input = Console.ReadLine();
            Console.WriteLine("Zadejte druhé číslo");
            string input2 = Console.ReadLine();
            Console.WriteLine();

            if (int.TryParse(input, out int cislo))
            {
                if (int.TryParse(input2, out int cislo2))
                {
                    Ukol3Proces(cislo, cislo2);
                }
                else
                {
                    Console.WriteLine("Error");
                }
            }
            else
            {
                Console.WriteLine("Error");
            }
            Console.WriteLine();
            moznost();
        }

        public static void Ukol3Proces(int cislo, int cislo2)
        {
            if (cislo < cislo2)
            {
                for (int i = cislo; i <= cislo2; i++)
                {
                    Console.WriteLine(i);
                }
            }
            else if (cislo > cislo2)
            {
                for (int i = cislo; i >= cislo2; i--)
                {
                    Console.WriteLine(i);
                }
            }
            else if (cislo == cislo2)
            {
                Console.WriteLine(cislo);
            }
        }

        public static void Ukol4()
        {
            Console.WriteLine("Úkol 4");
            Console.WriteLine("Zadejte číslo");
            string input = Console.ReadLine();
            Console.WriteLine();

            if (int.TryParse(input, out int cislo))
            {
                int cislo2 = cislo;
                for (int l = 0; l < cislo2; l++)
                {
                    cislo--;
                    for (int i = cislo; i > 0; i = --i)
                    {
                        int kolik = i;

                        for (int p = kolik; p == kolik; p++)
                        {
                            Console.Write(" ");
                        }
                    }
                    Console.Write(l + 1);
                    Console.WriteLine();
                }
            }
            Console.WriteLine();
            moznost();
        }

        public static void Ukol5()
        {
            Console.WriteLine("Úkol 5");
            Console.WriteLine("Zadejte číslo v rozmezí 11 až 99");
            string input = Console.ReadLine();
            Console.WriteLine();

            if (int.TryParse(input, out int cislo) && cislo >= 11 && cislo <= 99)
            {
                int deleni = cislo / 10;
                int zbytek = cislo % 10;
                zbytek++;

                //Mezery a |
                for (int i = 0; i < deleni; i++)
                {
                    if(i == 0)
                    {
                        for (int p = 1; p <= 9; p++)
                        {
                                Console.Write(" ");
                        }
                    }
                    else
                    {
                        for (int p = 0; p <= 9; p++)
                        {
                            if (p == 0)
                            {
                                Console.Write("|");
                            }
                            else
                            {
                                Console.Write(" ");
                            }
                        }
                    }
                }
                for (int l = 0; l < zbytek; l++)
                {
                    if (l == 0)
                    {
                        Console.Write("|");
                    }
                    else
                    {
                        Console.Write(" ");
                    }
                }

                Console.WriteLine();

                //Čísla
                for (int i = 0; i < deleni; i++)
                {
                    if (i == 0)
                    {
                        for (int p = 1; p <= 9; p++)
                        {
                            Console.Write(p);
                        }
                    }
                    else
                    {
                        for (int p = 0; p <= 9; p++)
                        {
                            Console.Write(p);
                        }
                    }
                }
                for (int l = 0; l < zbytek; l++)
                {
                    Console.Write(l);
                }
            }
            else
            {
                Console.WriteLine("Error");
            }
            Console.WriteLine();
            moznost();
        }

        public static void Ukol6()
        {
            Console.WriteLine("Úkol 6");
            Console.WriteLine("Zadejte číslo");
            string zadaneCislo = Console.ReadLine();
            Console.WriteLine();

            if (int.TryParse(zadaneCislo, out int cislo))
            {
                Ukol6Proces(cislo);
            }
            else
            {
                Console.WriteLine("Error");
            }
            Console.WriteLine();
            moznost();
        }

        public static void Ukol6Proces(int cislo)
        {
            Console.WriteLine("Úkol 6");
            Console.WriteLine("Zadejte číslo");
            cislo++;
            for (int i = 1; i < cislo; i++)
            {
                Console.Write("[" + i + "]");
                Console.Write(" ");
            }
            Console.WriteLine();
            moznost();
        }

        public static void Ukol7()
        {
            Console.WriteLine("Úkol 7");
            Console.WriteLine("Zadejte m");
            string input1 = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("Zadejte n");
            string input2 = Console.ReadLine();
            Console.WriteLine("");

            if (int.TryParse(input1, out int m))
            {
                if (int.TryParse(input2, out int n))
                {
                    Ukol7Proces(m, n);
                }
                else
                {
                    Console.WriteLine("Error");
                }
            }
            else
            {
                Console.WriteLine("Error");
            }          
            Console.WriteLine();
            moznost();
        }
        public static void Ukol7Proces(int m, int n)
        {
            int[,] tabule = new int[m, n];
            int idk = 0;
            for (int i = 0; n > i; i++)
            {
                for (int p = 0; m > p; p++)
                {
                    idk++;
                    tabule[p, i] = idk;
                }
            }
            for (int i = 0; tabule.GetLength(0) > i; i++)
            {
                for (int p = 0; tabule.GetLength(1) > p; p++)
                {
                    Console.Write(tabule[i, p] + "\t");
                }
                Console.WriteLine();
            }
        }

        public static void Ukol8()
        {
            Console.WriteLine("Úkol 8");
            Console.WriteLine("Zadejte celá čísla");
            Console.WriteLine("Zadejte x1");
            string X1 = Console.ReadLine();
            Console.WriteLine("Zadejte y1");
            string Y1 = Console.ReadLine();
            Console.WriteLine("Zadejte x2");
            string X2 = Console.ReadLine();
            Console.WriteLine("Zadejte y2");
            string Y2 = Console.ReadLine();

            if(double.TryParse(X1, out double x1))
            {
                if (double.TryParse(Y1, out double y1))
                {
                    if (double.TryParse(X2, out double x2))
                    {
                        if (double.TryParse(Y2, out double y2))
                        {
                            double vysledek = Math.Sqrt(((x1 - x2) * (x1 - x2)) + ((y1 - y2) * (y1 - y2)));
                            Console.WriteLine();
                            Console.WriteLine("Vzdálenost je : " + vysledek);
                        }
                        else
                        {
                            Console.WriteLine("Error");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error");
                    }
                }
                else
                {
                    Console.WriteLine("Error");
                }
            }
            else
            {
                Console.WriteLine("Error");
            }
            Console.WriteLine();
            moznost();
        }

        public static void Ukol9()
        {
            Console.WriteLine("Úkol 9");
            Console.WriteLine("Zadejte Text");
            string input = Console.ReadLine();
            Console.WriteLine();

            int l = 0;
            while (l <= input.Length - 1)
            {
                Console.WriteLine(input[l]);
                l++;
            }
            Console.WriteLine();
            moznost();
        }
    
        public static void Ukol10()
        {
            Console.WriteLine("Úkol 10");
            Console.WriteLine("Zadejte Text");
            Console.WriteLine();
            Console.WriteLine(Ukol10Proces());
            Console.WriteLine();
            moznost();
        }

        public static string Ukol10Proces()
        {
            string input = Console.ReadLine();
            Console.WriteLine();

            string output = new string(input.Reverse().ToArray());
            return output;
        }

        public static void Ukol11()
        {
            Console.WriteLine("Úkol 11");
            Console.WriteLine("Zadejte rodnecislo");
            Console.WriteLine();
            Console.WriteLine(Ukol11Proces());
            Console.WriteLine();
            moznost();

        }

        public static string Ukol11Proces()
        {
            string input = Console.ReadLine();
            Console.WriteLine();

            if (input[2].Equals('6') || input[2].Equals('5'))
            {
                return "Jedná se o ženu";
            }
            else if (input[2].Equals('1') || input[2].Equals('0'))
            {
                return "Jedná se o muže";
            }
            else
            {
                return "Error";
            }
        }

        public static void Ukol12()
        {
            Console.WriteLine("Úkol 12");           
            Console.WriteLine(Ukol12Proces());
            Console.WriteLine();
            moznost();
        }

        public static string Ukol12Proces()
        {
            Console.WriteLine("Zadejte den");
            string input2 = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("Zadejte měsíc");
            Console.WriteLine();
            string input1 = Console.ReadLine();

            if (int.TryParse(input1, out int mesic) && int.TryParse(input2, out int den))
            {
                if (mesic <= 12 && den <= 31)
                {
                    if (mesic == 12 && den >= 21 || (mesic >= 1 && mesic <= 3 && den < 20))
                    {
                        Console.WriteLine();
                        return "Zima";
                    }
                    else if (mesic == 3 && den >= 20 || (mesic <= 5 && mesic >= 4) || (mesic == 6 && den < 21))
                    {
                        Console.WriteLine();
                        return "Jaro";
                    }
                    else if (mesic == 6 && den >= 21 || (mesic >= 7 && mesic <= 8) || (mesic == 9 && den < 23))
                    {
                        Console.WriteLine();
                        return "Léto";
                    }
                    else if (mesic == 9 && den >= 23 || (mesic >= 10 && mesic <= 11) || (mesic == 12 && den < 21))
                    {
                        Console.WriteLine();
                        return "Podzim";
                    }
                    else
                    {
                        return "Error";
                    }
                }
                else
                {
                    return "Error";
                }
            }
            else
            {
                return "Error";
            }
        }

        public static void moznost()
        {
            Console.WriteLine("################################################################");
            Console.WriteLine("Vyberte jednu z možností :");
            Console.WriteLine("–––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––");
            Console.WriteLine("Ukol1_2" + "\t" + "Ukol4" + "\t" + "Ukol6" + "\t" + "Ukol8" + "\t" + "Ukol10" );
            Console.WriteLine("Ukol3" + "\t" + "Ukol5" + "\t" + "Ukol7" + "\t" + "Ukol9" + "\t" + "Ukol11" + "\t" + "Ukol12");
            Console.WriteLine("################################################################");
            Console.WriteLine("Pro ukončení programu napište : Exit");
            Console.WriteLine("################################################################");
            Console.Title = "🤘( ͡❛ ͜ʖ ͡❛)っ Code By Gamrus";
            string Moznost = Console.ReadLine();

            switch (Moznost)
            {
                case "Ukol1_2":
                    Console.WriteLine();
                    Ukol1_2();
                    break;
                case "Ukol3":
                    Console.WriteLine();
                    Ukol3();
                    break;
                case "Ukol4":
                    Console.WriteLine();
                    Ukol4();
                    break;
                case "Ukol5":
                    Console.WriteLine();
                    Ukol5();
                    break;
                case "Ukol6":
                    Console.WriteLine();
                    Ukol6();
                    break;
                case "Ukol7":
                    Console.WriteLine();
                    Ukol7();
                    break;
                case "Ukol8":
                    Console.WriteLine();
                    Ukol8();
                    break;
                case "Ukol9":
                    Console.WriteLine();
                    Ukol9();
                    break;
                case "Ukol10":
                    Console.WriteLine();
                    Ukol10();
                    break;
                case "Ukol11":
                    Console.WriteLine();
                    Ukol11();
                    break;
                case "Ukol12":
                    Console.WriteLine();
                    Ukol12();
                    break;
                case "Exit":
                    Console.WriteLine();
                    break;

            }
        }
        static void Main(string[] args)
        {    
            
            moznost();  
            
        }
    }
}
