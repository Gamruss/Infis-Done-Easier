﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections;
using System.IO;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        static ArrayList nazvy = new ArrayList();
        static ArrayList texty = new ArrayList();

        public static Boolean nacistData(String soubor)
        {
            string cesta = @soubor;
            if(!File.Exists(cesta))
            {
                MessageBox.Show("Nenalezeno");
                return false;
            }
            string[] radky = File.ReadAllLines(cesta);
            foreach (string radek in radky)
            {
                string nazev = radek.Split('~')[0];
                string souborText = radek.Split('~')[1];

                nazvy.Add(nazev);
                texty.Add(File.ReadAllText(souborText));
            }
            return true;
        }

        public static void naplnitCombo(ComboBox seznam)
        {
            foreach(string item in nazvy)
            {
                seznam.Items.Add(item);
            }
        }


        public MainWindow()
        {
            InitializeComponent();
            if (nacistData("toc.txt"))
            {
                naplnitCombo(ComboNazavy);
            }
            else
            {
                MessageBox.Show("konec");
                Environment.Exit(0);
            }
        }


        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            lmao.Text = texty[ComboNazavy.SelectedIndex].ToString();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Clipboard.SetText(lmao.Text);
        }
    }
}
