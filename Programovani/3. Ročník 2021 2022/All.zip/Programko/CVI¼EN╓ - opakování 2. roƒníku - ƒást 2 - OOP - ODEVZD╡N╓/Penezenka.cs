﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    class Penezenka
    {
        public int stav;

        public void vloz(int hodnota)
        {
            stav = stav + hodnota;
        }

        public void vyber(int hodnota)
        {
            stav = stav - hodnota;
        }

        public void zustatek()
        {
            Console.WriteLine("Zustatek na účtě činí : " + stav + " CZK");
        }

        public Penezenka(int stav)
        {
            this.stav = stav;
        }
    }
}
