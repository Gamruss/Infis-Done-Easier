﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp4
{
    class Ucet
    {
        /// Hodnoty
        /// 
        /// 
        private string cisloUctu;
        private double zustatek;
        ///
        ///
        /// ///


        /// GetterSetter
        /// 
        /// 
        public string getCisloUctu()
        {
            return cisloUctu;
        }

        public void setCisloUctu(string CisloUctu)
        {
            CisloUctu = cisloUctu;
        }

        public double getZustatek()
        {
            return zustatek;
        }

        public void setZustatek(double Zustatek)
        {
            Zustatek = zustatek;
        }
        /// 
        ///
        /// ///

        /// METODY LMAO
        /// 
        ///
        public double Uloz(double castka)
        {
            return zustatek = zustatek + castka;
        }

        public double Vyber(double castka)
        {
            if(castka <= zustatek)
            {
                return zustatek = zustatek - castka;
            }
            else
            {
                return -1;
            }
        }

        public void Prevod(double castka, Ucet cisloUctu)
        {
            if (castka <= zustatek)
            {
                zustatek = zustatek - castka;
                cisloUctu.Uloz(castka);
            }
            else
            {

            }
        }
        ///
        ///
        /// ///


        /// Konstruktory
        ///
        ///
        public Ucet()
        {

        }

        public Ucet(string cisloUctu)
        {
            this.cisloUctu = cisloUctu;
        }

        public Ucet(string cisloUctu, double zustatek)
        {
            this.cisloUctu = cisloUctu;
            this.zustatek = zustatek;
        }
        ///
        ///
        /// ///
    }
}
