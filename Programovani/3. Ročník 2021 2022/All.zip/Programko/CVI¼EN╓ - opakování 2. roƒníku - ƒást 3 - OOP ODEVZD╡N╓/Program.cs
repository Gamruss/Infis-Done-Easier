﻿using System;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {

            
            Ucet ucet = new Ucet("xd1", 500);
            Ucet ucet2 = new Ucet("xd2", 400);
            ucet.Prevod(1, ucet2);
            Console.WriteLine(ucet.getZustatek());
            Console.WriteLine(ucet2.getZustatek());
            Console.WriteLine();


        }
    }
}
