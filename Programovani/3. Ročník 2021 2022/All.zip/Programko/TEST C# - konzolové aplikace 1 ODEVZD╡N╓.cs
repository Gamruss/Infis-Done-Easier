﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        public static bool slovaxd(string slovo)
        {           
            for (int i = 0; i < slovo.Length; i++)
            {
                if (slovo.LastIndexOf(slovo[i]) != i)
                {
                return true;
                }
            }
            return false;         
        }

        public static void kosoctverec()
        {
            int xdd = 4; 
            int kolik = 1;
            for (int i = 0; i < xdd; i++)
            {
                for (int p = 0; p < xdd; p++)
                {
                    Console.Write(" ");                  
                }
                for (int j = 0; j < kolik; j++)
                {
                    Console.Write("x");
                }

                Console.WriteLine();
            }


        }
        static void Main(string[] args)
        {
            //Ukol1
            Console.WriteLine(slovaxd("hello")); 



            //Ukol2
            string Jmeno = "Karel Novák";
            string[] slova = Jmeno.Split(new[] { ' ' }, 2);
            string wordsAfter = string.Format("{0} {1}", slova[0], slova[1]);
            Console.WriteLine(slova[1]+" "+ slova[0]);


            //Ukol3
            kosoctverec();
        }
    }
}
