﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Kure
    {
        public string jmeno;
        public int energie;

        public void setJmeno(string Jmeno)
        {
            Jmeno = jmeno;
        }
        public void setEnergie(int Energie)
        {
            if(Energie > 100)
            {
                Console.WriteLine("Špatná hodnota");
            }
            else
            {
                Energie = energie;
            }
            
        }
        public string getJmeno()
        {
            return jmeno;
        }
        public int getEnergie()
        {
            return energie;
        }

        public void najezSe(int jidlo)
        {
            if(jidlo >= 100)
            {
                Console.WriteLine("Už nemůžu");
                Console.WriteLine("Kuře by přesáhlo limit 100");
            }
            else
            {
                Console.WriteLine("Kuře se najedlo o hodnotu : "+ jidlo );
                energie = energie + jidlo;
            }
        }

        public Kure()
        {

        }
        public Kure(string Jmeno)
        {
            this.jmeno = Jmeno; 
        }
    }
}
