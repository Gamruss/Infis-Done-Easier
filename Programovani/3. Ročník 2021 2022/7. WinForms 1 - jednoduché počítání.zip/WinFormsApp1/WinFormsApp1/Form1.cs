﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {

        private double Ukol_1_ulozeneCislo;
        public Form1()
        {
            InitializeComponent();
        }

        private void Ukol_1_Pricti_Click(object sender, EventArgs e)
        {
            if (double.TryParse(Ukol_1_UserInput.Text, out double cislo) && Ukol_1_Vynuluj.Checked == true)
            {
                Ukol_1_ulozeneCislo = 0;
                Ukol_1_Vypis.Text = Ukol_1_ulozeneCislo.ToString();
            }
            else if (double.TryParse(Ukol_1_UserInput.Text, out double cislo2))
            {
                Ukol_1_ulozeneCislo = cislo2 + Ukol_1_ulozeneCislo;
                Ukol_1_Vypis.Text = Ukol_1_ulozeneCislo.ToString();
            }
            else
            {
                Ukol_1_Vypis.Text = "Error";
            }
        }

        private void Ukol__1_Odecti_Click(object sender, EventArgs e)
        {
            if (double.TryParse(Ukol_1_UserInput.Text, out double cislo) && Ukol_1_Vynuluj.Checked == true)
            {
                Ukol_1_ulozeneCislo = 0;
                Ukol_1_Vypis.Text = Ukol_1_ulozeneCislo.ToString();
            }
            else if (double.TryParse(Ukol_1_UserInput.Text, out double cislo2))
            {
                Ukol_1_ulozeneCislo = Ukol_1_ulozeneCislo - cislo2;
                Ukol_1_Vypis.Text = Ukol_1_ulozeneCislo.ToString();
            }
            else
            {
                Ukol_1_Vypis.Text = "Error";
            }
        }

        private void SidePanelButton1_Hover(object sender, EventArgs e)
        {
            SidePanelButton1.BackColor = Color.FromArgb(85, 85, 85);
        }

        private void SidePanelButton1_MouseLeave(object sender, EventArgs e)
        {
            SidePanelButton1.BackColor = Color.FromArgb(77, 77, 77);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
