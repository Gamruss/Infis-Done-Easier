﻿
namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Ukol_1_Vypis = new System.Windows.Forms.TextBox();
            this.Ukol_1_Pricti = new System.Windows.Forms.Button();
            this.Ukol__1_Odecti = new System.Windows.Forms.Button();
            this.Ukol_1_UserInput = new System.Windows.Forms.TextBox();
            this.Ukol_1_Vynuluj = new System.Windows.Forms.CheckBox();
            this.SidePanelMenu = new System.Windows.Forms.Panel();
            this.SidePanelButton1 = new System.Windows.Forms.Button();
            this.SidePanelLogo = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SidePanelMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.Ukol_1_Vypis);
            this.panel1.Controls.Add(this.Ukol_1_Pricti);
            this.panel1.Controls.Add(this.Ukol__1_Odecti);
            this.panel1.Controls.Add(this.Ukol_1_UserInput);
            this.panel1.Controls.Add(this.Ukol_1_Vynuluj);
            this.panel1.Location = new System.Drawing.Point(261, 50);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(527, 234);
            this.panel1.TabIndex = 0;
            // 
            // Ukol_1_Vypis
            // 
            this.Ukol_1_Vypis.Location = new System.Drawing.Point(321, 68);
            this.Ukol_1_Vypis.Name = "Ukol_1_Vypis";
            this.Ukol_1_Vypis.Size = new System.Drawing.Size(100, 23);
            this.Ukol_1_Vypis.TabIndex = 5;
            // 
            // Ukol_1_Pricti
            // 
            this.Ukol_1_Pricti.Location = new System.Drawing.Point(150, 68);
            this.Ukol_1_Pricti.Name = "Ukol_1_Pricti";
            this.Ukol_1_Pricti.Size = new System.Drawing.Size(75, 23);
            this.Ukol_1_Pricti.TabIndex = 3;
            this.Ukol_1_Pricti.Text = "Přičti";
            this.Ukol_1_Pricti.UseVisualStyleBackColor = true;
            this.Ukol_1_Pricti.Click += new System.EventHandler(this.Ukol_1_Pricti_Click);
            // 
            // Ukol__1_Odecti
            // 
            this.Ukol__1_Odecti.Location = new System.Drawing.Point(231, 68);
            this.Ukol__1_Odecti.Name = "Ukol__1_Odecti";
            this.Ukol__1_Odecti.Size = new System.Drawing.Size(75, 23);
            this.Ukol__1_Odecti.TabIndex = 2;
            this.Ukol__1_Odecti.Text = "Odečti";
            this.Ukol__1_Odecti.UseVisualStyleBackColor = true;
            this.Ukol__1_Odecti.Click += new System.EventHandler(this.Ukol__1_Odecti_Click);
            // 
            // Ukol_1_UserInput
            // 
            this.Ukol_1_UserInput.Location = new System.Drawing.Point(44, 68);
            this.Ukol_1_UserInput.Name = "Ukol_1_UserInput";
            this.Ukol_1_UserInput.Size = new System.Drawing.Size(100, 23);
            this.Ukol_1_UserInput.TabIndex = 1;
            // 
            // Ukol_1_Vynuluj
            // 
            this.Ukol_1_Vynuluj.AutoSize = true;
            this.Ukol_1_Vynuluj.Location = new System.Drawing.Point(44, 107);
            this.Ukol_1_Vynuluj.Name = "Ukol_1_Vynuluj";
            this.Ukol_1_Vynuluj.Size = new System.Drawing.Size(65, 19);
            this.Ukol_1_Vynuluj.TabIndex = 0;
            this.Ukol_1_Vynuluj.Text = "vynuluj";
            this.Ukol_1_Vynuluj.UseVisualStyleBackColor = true;
            // 
            // SidePanelMenu
            // 
            this.SidePanelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(77)))), ((int)(((byte)(77)))));
            this.SidePanelMenu.Controls.Add(this.SidePanelButton1);
            this.SidePanelMenu.Controls.Add(this.SidePanelLogo);
            this.SidePanelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.SidePanelMenu.Location = new System.Drawing.Point(0, 0);
            this.SidePanelMenu.Name = "SidePanelMenu";
            this.SidePanelMenu.Size = new System.Drawing.Size(200, 485);
            this.SidePanelMenu.TabIndex = 1;
            // 
            // SidePanelButton1
            // 
            this.SidePanelButton1.Dock = System.Windows.Forms.DockStyle.Top;
            this.SidePanelButton1.FlatAppearance.BorderSize = 0;
            this.SidePanelButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SidePanelButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SidePanelButton1.Location = new System.Drawing.Point(0, 75);
            this.SidePanelButton1.Name = "SidePanelButton1";
            this.SidePanelButton1.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.SidePanelButton1.Size = new System.Drawing.Size(200, 50);
            this.SidePanelButton1.TabIndex = 1;
            this.SidePanelButton1.Text = "button1";
            this.SidePanelButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SidePanelButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.SidePanelButton1.UseVisualStyleBackColor = true;
            this.SidePanelButton1.MouseLeave += new System.EventHandler(this.SidePanelButton1_MouseLeave);
            this.SidePanelButton1.MouseHover += new System.EventHandler(this.SidePanelButton1_Hover);
            // 
            // SidePanelLogo
            // 
            this.SidePanelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(58)))));
            this.SidePanelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.SidePanelLogo.Location = new System.Drawing.Point(0, 0);
            this.SidePanelLogo.Name = "SidePanelLogo";
            this.SidePanelLogo.Size = new System.Drawing.Size(200, 75);
            this.SidePanelLogo.TabIndex = 0;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(428, 13);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 6;
            this.button3.Text = "konec";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.ClientSize = new System.Drawing.Size(838, 485);
            this.Controls.Add(this.SidePanelMenu);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.MouseHover += new System.EventHandler(this.SidePanelButton1_Hover);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.SidePanelMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox Ukol_1_Vypis;
        private System.Windows.Forms.Button Ukol_1_Pricti;
        private System.Windows.Forms.Button Ukol__1_Odecti;
        private System.Windows.Forms.TextBox Ukol_1_UserInput;
        private System.Windows.Forms.CheckBox Ukol_1_Vynuluj;
        private System.Windows.Forms.Panel SidePanelMenu;
        private System.Windows.Forms.Panel SidePanelLogo;
        private System.Windows.Forms.Button SidePanelButton1;
        private System.Windows.Forms.Button button3;
    }
}

