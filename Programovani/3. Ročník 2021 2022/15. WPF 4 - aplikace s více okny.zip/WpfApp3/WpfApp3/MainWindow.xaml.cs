﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        

        public static string jmeno;
        public static double penize;
        private double Penize = 0;


        public MainWindow()
        {
            InitializeComponent();
            MWPenezenkaBox.Text = Penize.ToString();
        }


        private void MWVlozButton_Click(object sender, RoutedEventArgs e)
        {
            Window1 w1 = new Window1();
            w1.Title = "Majitel : " + MWJmenoBox.Text;
            w1.ShowDialog();
            Penize = Penize + penize;
            MWPenezenkaBox.Text = Penize.ToString();


        }

        private void MWVyberButton_Click(object sender, RoutedEventArgs e)
        {
            Window2 w2 = new Window2();
            w2.Title = "Majitel : " + MWJmenoBox.Text;
            w2.ShowDialog();
            if (Penize < penize)
            {
                MessageBox.Show("Nemáš peníze xd");
            }
            else
            {
                Penize = Penize - penize;
                MWPenezenkaBox.Text = Penize.ToString();
            }
            
        }

        private void MWUlozJmenoButton_Click(object sender, RoutedEventArgs e)
        {
            Title = "Majitel : " + MWJmenoBox.Text;
        }
    }
}
