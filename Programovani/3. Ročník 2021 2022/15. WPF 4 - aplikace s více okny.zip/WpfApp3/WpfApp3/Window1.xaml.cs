﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interakční logika pro Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        
        public Window1()
        {
            InitializeComponent();
        }

        private void W1VlozButton_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(W1CastkaBox.Text, out double castka))
            {

                MainWindow.penize = double.Parse(W1CastkaBox.Text);
                this.Close();

            }
            else
            {
                MessageBox.Show("tohle neni čislo pepego");
            }
        }

        private void W1ZrusitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();           
        }
    }
}
