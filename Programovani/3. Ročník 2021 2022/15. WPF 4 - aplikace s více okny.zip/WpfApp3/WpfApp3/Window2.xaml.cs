﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interakční logika pro Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        
        public Window2()
        {
            InitializeComponent();
        }

        private void W2ZrusitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();           
        }

        private void W2VyberButton_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(W2CastkaBox.Text, out double castka))
            {

                MainWindow.penize = double.Parse(W2CastkaBox.Text);
                this.Close();

            }
            else
            {
                MessageBox.Show("tohle neni čislo pepego");
            }
        }
    }
}
