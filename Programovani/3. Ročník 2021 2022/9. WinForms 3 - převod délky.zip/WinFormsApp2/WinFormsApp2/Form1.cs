﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Moznosti.SelectedIndex = 1;
        }

        private void Moznosti_SelectedIndexChanged(object sender, EventArgs e)
        {
            Vypocet();
        }

        private void Hodnota_ValueChanged(object sender, EventArgs e)
        {
            Vypocet();
        }

        private void Vypocet()
        {
            if (Moznosti.Text == "mm")
            {
                double hodnota = (double)Hodnota.Value * 1000;
                Vypis.Text = hodnota.ToString();
            }
            else if (Moznosti.Text == "cm")
            {
                double hodnota = (double)Hodnota.Value * 100;
                Vypis.Text = hodnota.ToString();
            }
            else if (Moznosti.Text == "dm")
            {
                double hodnota = (double)Hodnota.Value * 10;
                Vypis.Text = hodnota.ToString();
            }
            else if (Moznosti.Text == "km")
            {
                double hodnota = (double)Hodnota.Value / 1000;
                Vypis.Text = hodnota.ToString();
            }
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
