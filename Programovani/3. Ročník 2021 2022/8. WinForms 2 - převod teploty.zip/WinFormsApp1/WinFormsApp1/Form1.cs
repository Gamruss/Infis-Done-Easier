﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public int What = 0;
        public int number = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Prevod1_Click(object sender, EventArgs e)
        {
            if (What == 0)
            {
                
                double xd = (double)Celcius.Value;
                if(xd == 0)
                {
                    xd = 32;
                    Fernh.Text = xd.ToString();
                }
                else
                {
                    xd = (xd * 9) / 5 + 32;
                    xd = Math.Round(xd, 1);
                    Fernh.Text = xd.ToString();
                }
                
            }
            else if (What == 1)
            {
                double xd = (double)Celcius.Value;
                xd = (xd - 32) * 5 / 9;
                xd = Math.Round(xd, 1);
                Fernh.Text = xd.ToString();
            }
            
            
        }

        private void Celcius_ValueChanged(object sender, EventArgs e)
        {
            if(Celcius.Value<0)
            {
                Celcius.ForeColor = Color.Red;
            }
            else if (Celcius.Value == 0)
            {
                Celcius.ForeColor = Color.Black;
            }
            else
            {
                Celcius.ForeColor = Color.Blue;
            }
        }

        private void Prehozeni_Click(object sender, EventArgs e)
        {

            if(number == 0)
            {
                label3.Text = "C";
                label2.Text = "F";
                label1.Text = "F 🡆 C";
                Prehozeni.Text = "F 🡆 C";
                What = 1;
                number = 1;

            }
            else if (number == 1)
            {
                label3.Text = "F";
                label2.Text = "C";
                label1.Text = "C 🡆 F";
                Prehozeni.Text = "C 🡆 F";
                What = 0;
                number = 0;
            }
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
