﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    class Obdelnik
    {
        public int strA;
        public int strB;

        public int obsah()
        {
            return (strA * strB);
        }

        public int obvod()
        {
            return (strA + strA + strB + strB);
        }

        public Obdelnik(int strA, int strB)
        {
            this.strA = strA;
            this.strB = strB;
        }
    }
}
