﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    class Zvire
    {
        public string jmeno;
        public string vydavavanyZvuk;
        public int pocetKoncetin;

        public void predstavSe()
        {
            Console.WriteLine("Jsem" + jmeno + " dělám" + vydavavanyZvuk + " a mám" + pocetKoncetin + " končetiny!");
        }
    }
}
