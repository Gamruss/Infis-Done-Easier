﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Zvire zvr = new Zvire();
            zvr.jmeno = "xd";
            zvr.vydavavanyZvuk = "xd";
            zvr.pocetKoncetin = 8;
            zvr.predstavSe();

            Console.WriteLine();

            int strA = 5;
            int strB = 6;
            Obdelnik obl = new Obdelnik(strA, strB);
            Console.WriteLine("Obvod : "+ obl.obvod());
            Console.WriteLine("Obsah : " + obl.obsah());

            Console.WriteLine();

            int stav = 0;
            Penezenka pz = new Penezenka(stav);
            pz.vloz(500);
            pz.vyber(100);
            pz.vloz(200);
            pz.zustatek();

        }
    }
}
