﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static int OdNumber;
        public static int DoNumber;
        private int PocetPokusu;
        private int Uhodni;

        public MainWindow()
        {
            InitializeComponent();
            OdNumber = 1;
            DoNumber = 5;
            PocetPokusu = 0;
            MWGuessPanel.Visibility = Visibility.Collapsed;
            MWGuessPanel2.Visibility = Visibility.Collapsed;
        }

        private void MWSettingsButton_Click(object sender, RoutedEventArgs e)
        {
            Window1 w1 = new Window1();
            w1.ShowDialog();
            MWGuessTextBlock.Text = "Hádej číslo od " + OdNumber + " do " + DoNumber;
            
        }



        private void MWGuessButton_Click(object sender, RoutedEventArgs e)
        {
            int number;
            PocetPokusu++;
            MWPocet_Pokusu.Text = "Pokusů : " + PocetPokusu;
            if(int.TryParse(MWGuessTextBox.Text, out number))
            {
                if(number == Uhodni)
                {
                    MWGuessPanel2.Visibility = Visibility.Collapsed;
                    MessageBox.Show("Vyhrál si \nČíslo uhodnuto \nPočet pokusů : " + PocetPokusu);
                    MWGuessPanel.Visibility = Visibility.Collapsed;
                    MWSettingsButton.IsEnabled = true;
                    PocetPokusu = 0;
                    MWBlankTextBox.Text = "";
                }
                else
                {
                    MWBlankTextBox.Text += MWGuessTextBox.Text + "\n";
                    MessageBox.Show("Špatné číslo \n Zkus to znovu");
                }
            }
            else
            {
                MessageBox.Show("Zadejte číslo !");
            }
        }

        private void MWStartButton_Click(object sender, RoutedEventArgs e)
        {
            Random random = new Random();
            Uhodni = random.Next(OdNumber, DoNumber);
            MWSettingsButton.IsEnabled = false;
            MWGuessPanel.Visibility = Visibility.Visible;
            MWGuessPanel2.Visibility = Visibility.Visible;
        }

        private void MWExitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
