﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interakční logika pro Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void W1UlozButton_Click(object sender, RoutedEventArgs e)
        {
            int number;            
            if(int.TryParse(W1OdTextBox.Text, out number))
            {
                if(number < int.Parse(W1DoTextBox.Text))
                {
                    MainWindow.OdNumber = number;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Error");

                }
            }
            else
            {
                MessageBox.Show("Error");
            }

            if(int.TryParse(W1DoTextBox.Text, out number))
            {
                if (int.Parse(W1OdTextBox.Text) < number)
                {
                    MainWindow.DoNumber = number;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Error");
                    
                }
            }
            else
            {
                MessageBox.Show("Error");
            }
            
        }

        private void W1ExitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
