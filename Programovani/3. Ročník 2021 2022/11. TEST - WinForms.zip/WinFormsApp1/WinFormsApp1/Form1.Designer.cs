﻿
namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.Vyhodnotit = new System.Windows.Forms.Button();
            this.HNumber = new System.Windows.Forms.NumericUpDown();
            this.DNumber = new System.Windows.Forms.NumericUpDown();
            this.HText = new System.Windows.Forms.TextBox();
            this.DText = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DNumber)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Domácí tým";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Hostující tým";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.Vyhodnotit);
            this.panel1.Controls.Add(this.HNumber);
            this.panel1.Controls.Add(this.DNumber);
            this.panel1.Controls.Add(this.HText);
            this.panel1.Controls.Add(this.DText);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(244, 141);
            this.panel1.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(154, 66);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = "Konec";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Vyhodnotit
            // 
            this.Vyhodnotit.Location = new System.Drawing.Point(73, 66);
            this.Vyhodnotit.Name = "Vyhodnotit";
            this.Vyhodnotit.Size = new System.Drawing.Size(75, 23);
            this.Vyhodnotit.TabIndex = 6;
            this.Vyhodnotit.Text = "Vyhodnotit";
            this.Vyhodnotit.UseVisualStyleBackColor = true;
            this.Vyhodnotit.Click += new System.EventHandler(this.Vyhodnotit_Click);
            // 
            // HNumber
            // 
            this.HNumber.Location = new System.Drawing.Point(191, 29);
            this.HNumber.Name = "HNumber";
            this.HNumber.Size = new System.Drawing.Size(38, 23);
            this.HNumber.TabIndex = 5;
            // 
            // DNumber
            // 
            this.DNumber.Location = new System.Drawing.Point(191, 0);
            this.DNumber.Name = "DNumber";
            this.DNumber.Size = new System.Drawing.Size(38, 23);
            this.DNumber.TabIndex = 4;
            // 
            // HText
            // 
            this.HText.Location = new System.Drawing.Point(84, 29);
            this.HText.Name = "HText";
            this.HText.Size = new System.Drawing.Size(100, 23);
            this.HText.TabIndex = 3;
            // 
            // DText
            // 
            this.DText.Location = new System.Drawing.Point(85, 0);
            this.DText.Name = "DText";
            this.DText.Size = new System.Drawing.Size(100, 23);
            this.DText.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(275, 162);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DNumber)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Vyhodnotit;
        private System.Windows.Forms.NumericUpDown HNumber;
        private System.Windows.Forms.NumericUpDown DNumber;
        private System.Windows.Forms.TextBox HText;
        private System.Windows.Forms.TextBox DText;
    }
}

