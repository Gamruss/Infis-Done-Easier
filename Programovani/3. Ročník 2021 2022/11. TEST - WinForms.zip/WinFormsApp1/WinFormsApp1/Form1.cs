﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        int DHodnota;
        int HHodnota;
        string vyhraText;
        int hloupost;
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Vyhodnotit_Click(object sender, EventArgs e)
        {
            Hodnota();
            if(string.IsNullOrEmpty(DText.Text) || string.IsNullOrEmpty(HText.Text))
            {
                MessageBox.Show("Položka Prázdná", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(hloupost == 1)
            {               
                MessageBox.Show("Hloupost", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show(DText.Text + " - " + HText.Text + " " + DNumber.Value + ":" + HNumber.Value + "\n" + "\n" + vyhraText + "\n" + "\n" + DText.Text + " " + DHodnota + "\n" + HText.Text + " " + HHodnota);
            }
            
        }

        private void Hodnota ()
        {
            if(DNumber.Value>HNumber.Value)
            {
                if(DText.Text == "sparta" || DText.Text == "Sparta")
                {
                    hloupost = 1;
                }
                else
                {
                    vyhraText = "Výhra domácí";
                    DHodnota = 3;
                    HHodnota = 0;
                    hloupost = 0;
                }
            }
            else if (DNumber.Value < HNumber.Value)
            {
                vyhraText = "Výhra hostů";
                DHodnota = 0;
                HHodnota = 3;
                hloupost = 0;
            }
            else if (DNumber.Value == HNumber.Value)
            {
                vyhraText = "Remíza";
                DHodnota = 1;
                HHodnota = 1;
                hloupost = 0;
            }
        }
    }
}
