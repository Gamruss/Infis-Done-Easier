﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Confirm_Click(object sender, EventArgs e)
        {
            var Age = DifferenceYears(DateTimePicker.Value, DateTime.Today);

            if (!string.IsNullOrEmpty(JmenoBox.Text) &&
                (MaleButton.Checked || FemaleButton.Checked) &&
                !string.IsNullOrEmpty(PreferenceList.Text))
            {
                if(Age > 18)
                {
                    MessageBox.Show("Jméno: " + JmenoBox.Text + "\n" +
                                    "Datum narození: " + DateTimePicker.Value.ToString("dd.MM.yyyy") + "\n" +
                                    "Pohlaví: " + Gender() + "\n" +
                                    "Preference: " + PreferenceList.Text);
                }
                else
                {
                    MessageBox.Show("Seznamka je až od 18 let");
                }
            }
            else
            {
                MessageBox.Show("Vyplňte celý formulář");
            }
        }
        private int DifferenceYears(DateTime startDate, DateTime endDate)
        {
            return (endDate.Year - startDate.Year - 1) +
                (((endDate.Month > startDate.Month) ||
                ((endDate.Month == startDate.Month) && 
                (endDate.Day >= startDate.Day))) ? 1 : 0);
        }
        private string Gender()
        {
            if(MaleButton.Checked)
            {
                return "Muž";
            }
            else
            {
                return "Žena";
            }
        }
    }
}
