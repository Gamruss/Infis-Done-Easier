﻿
namespace WinFormsApp3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.SeznamkaLabel = new System.Windows.Forms.Label();
            this.exit = new System.Windows.Forms.Button();
            this.Confirm = new System.Windows.Forms.Button();
            this.PreferenceLabel = new System.Windows.Forms.Label();
            this.GenderLabel = new System.Windows.Forms.Label();
            this.DateLabel = new System.Windows.Forms.Label();
            this.JmenoLabel = new System.Windows.Forms.Label();
            this.PreferenceList = new System.Windows.Forms.ComboBox();
            this.FemaleButton = new System.Windows.Forms.RadioButton();
            this.MaleButton = new System.Windows.Forms.RadioButton();
            this.JmenoBox = new System.Windows.Forms.TextBox();
            this.DateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.SeznamkaLabel);
            this.panel1.Controls.Add(this.exit);
            this.panel1.Controls.Add(this.Confirm);
            this.panel1.Controls.Add(this.PreferenceLabel);
            this.panel1.Controls.Add(this.GenderLabel);
            this.panel1.Controls.Add(this.DateLabel);
            this.panel1.Controls.Add(this.JmenoLabel);
            this.panel1.Controls.Add(this.PreferenceList);
            this.panel1.Controls.Add(this.FemaleButton);
            this.panel1.Controls.Add(this.MaleButton);
            this.panel1.Controls.Add(this.JmenoBox);
            this.panel1.Controls.Add(this.DateTimePicker);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(331, 204);
            this.panel1.TabIndex = 0;
            // 
            // SeznamkaLabel
            // 
            this.SeznamkaLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SeznamkaLabel.BackColor = System.Drawing.Color.Transparent;
            this.SeznamkaLabel.Font = new System.Drawing.Font("Verdana", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SeznamkaLabel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.SeznamkaLabel.Location = new System.Drawing.Point(85, -2);
            this.SeznamkaLabel.Name = "SeznamkaLabel";
            this.SeznamkaLabel.Size = new System.Drawing.Size(200, 28);
            this.SeznamkaLabel.TabIndex = 11;
            this.SeznamkaLabel.Text = "Seznamka";
            this.SeznamkaLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exit
            // 
            this.exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.exit.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.exit.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.exit.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.exit.Location = new System.Drawing.Point(305, 3);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(23, 23);
            this.exit.TabIndex = 9;
            this.exit.Text = "X";
            this.exit.UseVisualStyleBackColor = false;
            // 
            // Confirm
            // 
            this.Confirm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Confirm.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.Confirm.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Confirm.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.Confirm.Location = new System.Drawing.Point(128, 167);
            this.Confirm.Name = "Confirm";
            this.Confirm.Size = new System.Drawing.Size(82, 25);
            this.Confirm.TabIndex = 9;
            this.Confirm.Text = "Odevzdat";
            this.Confirm.UseVisualStyleBackColor = false;
            this.Confirm.Click += new System.EventHandler(this.Confirm_Click);
            // 
            // PreferenceLabel
            // 
            this.PreferenceLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PreferenceLabel.AutoSize = true;
            this.PreferenceLabel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.PreferenceLabel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.PreferenceLabel.Location = new System.Drawing.Point(45, 142);
            this.PreferenceLabel.Name = "PreferenceLabel";
            this.PreferenceLabel.Size = new System.Drawing.Size(82, 19);
            this.PreferenceLabel.TabIndex = 8;
            this.PreferenceLabel.Text = "Preference";
            // 
            // GenderLabel
            // 
            this.GenderLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GenderLabel.AutoSize = true;
            this.GenderLabel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.GenderLabel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.GenderLabel.Location = new System.Drawing.Point(68, 87);
            this.GenderLabel.Name = "GenderLabel";
            this.GenderLabel.Size = new System.Drawing.Size(59, 19);
            this.GenderLabel.TabIndex = 7;
            this.GenderLabel.Text = "Pohlaví";
            // 
            // DateLabel
            // 
            this.DateLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DateLabel.AutoSize = true;
            this.DateLabel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.DateLabel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.DateLabel.Location = new System.Drawing.Point(9, 57);
            this.DateLabel.Name = "DateLabel";
            this.DateLabel.Size = new System.Drawing.Size(118, 19);
            this.DateLabel.TabIndex = 6;
            this.DateLabel.Text = "Datum Narození";
            // 
            // JmenoLabel
            // 
            this.JmenoLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.JmenoLabel.AutoSize = true;
            this.JmenoLabel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.JmenoLabel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.JmenoLabel.Location = new System.Drawing.Point(74, 26);
            this.JmenoLabel.Name = "JmenoLabel";
            this.JmenoLabel.Size = new System.Drawing.Size(53, 19);
            this.JmenoLabel.TabIndex = 5;
            this.JmenoLabel.Text = "Jméno";
            // 
            // PreferenceList
            // 
            this.PreferenceList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PreferenceList.FormattingEnabled = true;
            this.PreferenceList.Items.AddRange(new object[] {
            "Hledám muže",
            "Hledám ženu"});
            this.PreferenceList.Location = new System.Drawing.Point(128, 138);
            this.PreferenceList.Name = "PreferenceList";
            this.PreferenceList.Size = new System.Drawing.Size(121, 23);
            this.PreferenceList.TabIndex = 4;
            // 
            // FemaleButton
            // 
            this.FemaleButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.FemaleButton.AutoSize = true;
            this.FemaleButton.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.FemaleButton.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.FemaleButton.Location = new System.Drawing.Point(128, 112);
            this.FemaleButton.Name = "FemaleButton";
            this.FemaleButton.Size = new System.Drawing.Size(60, 23);
            this.FemaleButton.TabIndex = 3;
            this.FemaleButton.TabStop = true;
            this.FemaleButton.Text = "Žena";
            this.FemaleButton.UseVisualStyleBackColor = true;
            // 
            // MaleButton
            // 
            this.MaleButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MaleButton.AutoSize = true;
            this.MaleButton.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.MaleButton.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.MaleButton.Location = new System.Drawing.Point(128, 87);
            this.MaleButton.Name = "MaleButton";
            this.MaleButton.Size = new System.Drawing.Size(55, 23);
            this.MaleButton.TabIndex = 2;
            this.MaleButton.TabStop = true;
            this.MaleButton.Text = "Muž";
            this.MaleButton.UseVisualStyleBackColor = true;
            // 
            // JmenoBox
            // 
            this.JmenoBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.JmenoBox.Location = new System.Drawing.Point(128, 28);
            this.JmenoBox.Name = "JmenoBox";
            this.JmenoBox.Size = new System.Drawing.Size(200, 23);
            this.JmenoBox.TabIndex = 1;
            // 
            // DateTimePicker
            // 
            this.DateTimePicker.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DateTimePicker.Location = new System.Drawing.Point(128, 57);
            this.DateTimePicker.Name = "DateTimePicker";
            this.DateTimePicker.Size = new System.Drawing.Size(200, 23);
            this.DateTimePicker.TabIndex = 0;
            this.DateTimePicker.Value = new System.DateTime(2010, 1, 25, 15, 8, 0, 0);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 202);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Confirm;
        private System.Windows.Forms.Label PreferenceLabel;
        private System.Windows.Forms.Label GenderLabel;
        private System.Windows.Forms.Label DateLabel;
        private System.Windows.Forms.Label JmenoLabel;
        private System.Windows.Forms.ComboBox PreferenceList;
        private System.Windows.Forms.RadioButton FemaleButton;
        private System.Windows.Forms.RadioButton MaleButton;
        private System.Windows.Forms.TextBox JmenoBox;
        private System.Windows.Forms.DateTimePicker DateTimePicker;
        private System.Windows.Forms.Label SeznamkaLabel;
        private System.Windows.Forms.Button exit;
    }
}

